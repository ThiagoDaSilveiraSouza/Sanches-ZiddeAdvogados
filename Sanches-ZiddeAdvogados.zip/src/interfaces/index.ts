export * from "./ICompanyData"
export * from "./IPost"