export interface IHamburgerContent {
  isOpen: boolean;
  zIndex?: string;
  sizeToHidde?: string;
}
