export interface IButton {
  fontColor?: string;
  fontSize?: string;
  padding?: string;
  borderColor?: string;
  backgroundColor?: string;
}
