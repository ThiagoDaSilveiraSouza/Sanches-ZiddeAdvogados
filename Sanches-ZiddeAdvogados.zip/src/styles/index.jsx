export * from "./GlobalStyle";
