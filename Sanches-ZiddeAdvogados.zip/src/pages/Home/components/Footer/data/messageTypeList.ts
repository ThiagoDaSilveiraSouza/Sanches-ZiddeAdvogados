export const messageTypeList = {
  "200": {
    title: "Mesagem enviada com sucesso!",
  },
  "400": {
    title: "Mensagem não enviada, tente novamente.",
  },
};
