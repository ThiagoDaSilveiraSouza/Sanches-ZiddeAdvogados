export interface IOcupationAreaConfig {
  backgroundImg: string;
}

export interface ICard {
  icon: string;
  title: string;
  subTitle?: string;
  descriptionList: string[];
}
