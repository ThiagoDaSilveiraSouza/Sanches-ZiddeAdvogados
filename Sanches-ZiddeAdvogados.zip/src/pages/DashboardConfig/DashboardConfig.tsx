export const DashboardConfig = () => {
  return <h1>ConfigPage</h1>;
};
